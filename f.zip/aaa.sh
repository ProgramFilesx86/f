curl -s https://raw.githubusercontent.com/ProgramFilesx86/f/main/f.sh | 
bash

